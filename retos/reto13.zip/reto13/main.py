from HTTP_Requests.calculos import calcular_area_circulo, calcular_area_triangulo

calcular_area_triangulo()
calcular_area_circulo()