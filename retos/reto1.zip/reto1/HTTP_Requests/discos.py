def uno():
  disco1 = dict()
  disco1['nombre'] = "Motomami"
  disco1['artista'] = "Rosalia"
  disco1['año'] = "2022"
  disco1['precio'] = 13.99
  disco1['genero'] = "Pop"
  return (disco1)

def dos():
  disco2 = dict()
  disco2['nombre'] = "Global"
  disco2['artista'] = "Carl Cox"
  disco2['año'] = "2006"
  disco2['precio'] = 9.99
  disco2['genero'] = "Electro"
  return (disco2)

def tres():
  disco3 = dict()
  disco3['nombre'] = "El último tour del mundo"
  disco3['artista'] = "Bad Bunny"
  disco3['año'] = "2020"
  disco3['precio'] = 15.99
  disco3['genero'] = "Reggaeton"
  return (disco3)

def cuatro():
  disco4 = dict()
  disco4['nombre'] = "Appetite for Destruction"
  disco4['artista'] = "Gun's n Roses"
  disco4['año'] = "1987"
  disco4['precio'] = 19.99
  disco4['genero'] = "Rock"
  return (disco4)

def cinco():
  disco5 = dict()
  disco5['nombre'] = "Metallica"
  disco5['artista'] = "Metallica"
  disco5['año'] = "1991"
  disco5['precio'] = 18.99
  disco5['genero'] = "Metal"
  return (disco5)

def seis():
  disco6 = dict()
  disco6['nombre'] = "Deathgeneration"
  disco6['artista'] = "Avulsed"
  disco6['año'] = "2016"
  disco6['precio'] = 12.99
  disco6['genero'] = "Death Metal"
  return (disco6)

def siete():
  disco7 = dict()
  disco7['nombre'] = "Evangelion"
  disco7['artista'] = "Behemoth"
  disco7['año'] = "2009"
  disco7['precio'] = 14.99
  disco7['genero'] = "Black Metal"
  return (disco7)