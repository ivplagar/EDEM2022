from HTTP_Requests.functions import tienda as tienda

tienda()