from HTTP_Requests.calculos import calcular_volumen_cilindro

calcular_volumen_cilindro()